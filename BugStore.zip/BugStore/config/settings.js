const fs = require('fs')
const chalk = require('chalk')
// EDIT OWNER
global.owner = ['6285714640227']// no own
global.bugrup = ['6285714640227'] // ganti nomor wa lu
global.thumb = fs.readFileSync('./zans.jpg')
global.creAtor = "6285714640227@s.whatsapp.net" //Jangan Ganti Tar Error
global.ttname = '𝐋𝐞𝐱𝐱𝐲 - 𝐌𝐃⚡ || 𝐇𝐎𝐒𝐓𝐈𝐍𝐆'
global.packname = 'Cs Lexxy - MD⚡'
global.author = 'BY Lexxy - MD⚡'
global.sessionName = 'session' // nama session
global.delayy = 500;
// EDIT PANEL 
global.domain = 'https://panellexystore.panellstoree.com' // Isi Domain Lu
global.apikey = 'ptla_TsyBHEIIEwdhqrtYu2zgUyEVdbByek12FbBZhIVMMRH' // Isi Apikey Plta Lu
global.capikey = 'ptlc_NoW6dwKXmViRX4Kv9EChV21PP9XTBLa51rhc34npGQD' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id egg buat panel bot wa
global.eggspmmp = '-' // id egg buat pocketmine
global.eggsbedrock = '-' // id egg buat bedrock
global.eggsjava = '-' // id egg buat java
global.location = '1' // id location

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})