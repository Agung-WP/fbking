const fs = require('fs')

exports.groupResponse_Remove = async (zans, update) => {
try {
ppuser = await zans.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://telegra.ph/file/265c672094dfa87caea19.jpg'
}
const metadata = await zans.groupMetadata(update.id)
for (let participant of update.participants) {
try{
let metadata = await zans.groupMetadata(update.id)
let participants = update.participants
for (let num of participants) {
if (update.action == 'remove'){
var button = [{ buttonId: '!text_grup', buttonText: { displayText: 'Bye👋'}, type: 1 }]
await zans.sendMessage(
update.id, 
{
text: `┌─❖
│「 𝗛𝗶 👋 @${num.split("@")[0]} 」
└┬❖ 
   │✑ 𝗟𝗲𝗮𝘃𝗲 𝗧𝗼
   │✑ ${metadata.subject}
   └────────────────>`,
footer: metadata.subject, 
mentions: [num] })
}
}
} catch (err) {
console.log(err)
}
}   
}
  
exports.groupResponse_Welcome = async (zans, update) => {
try {
ppuser = await zans.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://telegra.ph/file/71329335164c62810363a.jpg'
}
const metadata = await zans.groupMetadata(update.id)   
for (let participant of update.participants) {
try{
let metadata = await zans.groupMetadata(update.id)
let participants = update.participants
for (let num of participants) {
if (update.action == 'add') {
var button = [{ buttonId: '!text_grup', buttonText: { displayText: 'Welcome👋'}, type: 1 }]
await zans.sendMessage(
update.id, 
{ 
text: `┌─❖
│「 𝗛𝗶 👋 @${num.split("@")[0]} 」
└┬❖ 
   │✑ 💌 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝗧𝗼 
   │✑ ${metadata.subject}
   │✑ 👥 𝗠𝗲𝗺𝗯𝗲𝗿 𝗞𝗲 
   │✑ ${metadata.participants.length ? metadata.participants.length : "Undefined"}
   └────────────────>`,
footer: metadata.subject,
mentions: [num] })
}
}
} catch (err) {
console.log(err)
}
}   
}
  
exports.groupResponse_Promote = async (zans, update) => {  
const metadata = await zans.groupMetadata(update.id)   
for (let participant of update.participants) {
try{
let metadata = await zans.groupMetadata(update.id)
let participants = update.participants
for (let num of participants) {
if (update.action == 'promote') {
var button = [{ buttonId: '!text_grup', buttonText: { displayText: 'Selamat🎉'}, type: 1 }]
await zans.sendMessage(
update.id, 
{ 
text: `*@${num.split("@")[0]} Naik jabatan jadi admin grup*`,
footer: metadata.subject,
mentions: [num] })
}
}
} catch (err) {
console.log(err)
}
}   
}
  
exports.groupResponse_Demote = async (zans, update) => {  
const metadata = await zans.groupMetadata(update.id)   
for (let participant of update.participants) {
try{
let metadata = await zans.groupMetadata(update.id)
let participants = update.participants
for (let num of participants) {
if (update.action == 'demote') {
var button = [{ buttonId: '!text_grup', buttonText: { displayText: 'Selamat🎉'}, type: 1 }]
await zans.sendMessage(
update.id, 
{ 
text: `*@${num.split("@")[0]} Turun jabatan menjadi member biasa*`,
footer: metadata.subject,
mentions: [num] })
}
}
} catch (err) {
console.log(err)
}
}   
}